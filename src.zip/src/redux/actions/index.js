export {
  genderSelection,
  changePage,
  clickedonGenderCard,
  returnToFirstPage,
} from "./GenderSel";

export {
  answerQuestion,
  changequestionPage,
  clickedonQuizCard,
  returnToPreviusQuestion,
  onArrow,
  clickedonNextButton,
  fetchData,
  goNext,
  sendInput,
  saveType,
  goToCheckout,
} from "./Quiz";

export { choosePlan } from "./Checkout";
