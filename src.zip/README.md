# Mint Project

Just some parts of the female section

## done:

- [responsive images] - done
- [responsive navigation logo] - done
- [active question checkmark] - done
- [active question border] - done
- [responsive options] - done
- [next button] - done
