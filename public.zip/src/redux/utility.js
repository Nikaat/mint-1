export const updateObject = (oldObject, upddatedObject) => {
  return {
    ...oldObject,
    ...upddatedObject,
  };
};
